{{- if .Values.sensor.enabled }}
{{- $name := printf "%s-sensor" .Release.Name }}
{{- $review := required "sensor SCC review digest required before activation" .Values.sensor.scc.reviewSha256 }}
{{- $h := .Values.sensor.hosted }}
{{- range $gate, $admitted := $h.gates }}
{{- if not $admitted }}{{- fail (printf "hosted activation refuses unqualified %s" $gate) }}{{- end }}
{{- end }}
{{- if or (empty $h.startupSecret.name) (empty $h.machineSecret.name) (empty $h.statusClaim.name) (empty $h.helperImage.repository) (empty $h.helperImage.digest) (not (regexMatch "^[a-f0-9]{64}$" $h.configurationSha256)) }}
{{- fail "hosted activation requires current independently selected references and protected config SHA" }}
{{- end }}
{{- $names := list $h.startupSecret.name $h.machineSecret.name .Values.sensor.producerKeySecret }}
{{- if ne (len (uniq $names)) 3 }}
{{- fail "startup machine and producer signing Secret custody must be distinct" }}
{{- end }}
{{- if empty (index .Values.sensor.nodeSelector "kubernetes.io/hostname") }}
{{- fail "hosted status single owner requires one exact node hostname" }}
{{- end }}
apiVersion: v1
kind: ServiceAccount
metadata:
  name: {{ $name }}
  namespace: {{ .Release.Namespace }}
automountServiceAccountToken: false
---
apiVersion: rbac.authorization.k8s.io/v1
kind: Role
metadata:
  name: {{ $name }}-scc
  namespace: {{ .Release.Namespace }}
rules:
- apiGroups: [security.openshift.io]
  resources: [securitycontextconstraints]
  resourceNames: [{{ printf "%s-%s" .Release.Namespace $name | quote }}]
  verbs: [use]
---
apiVersion: rbac.authorization.k8s.io/v1
kind: RoleBinding
metadata:
  name: {{ $name }}-scc
  namespace: {{ .Release.Namespace }}
roleRef:
  apiGroup: rbac.authorization.k8s.io
  kind: Role
  name: {{ $name }}-scc
subjects:
- kind: ServiceAccount
  name: {{ $name }}
  namespace: {{ .Release.Namespace }}
---
apiVersion: apps/v1
kind: DaemonSet
metadata:
  name: {{ $name }}
  namespace: {{ .Release.Namespace }}
  annotations:
    lorasis.io/required-review-sha256: {{ $review | quote }}
    lorasis.io/qualification: UNQUALIFIED
    lorasis.io/startup-config-sha256: {{ $h.configurationSha256 | quote }}
    lorasis.io/startup-secret-uid: {{ $h.startupSecret.uid | quote }}
    lorasis.io/startup-secret-resource-version: {{ $h.startupSecret.resourceVersion | quote }}
    lorasis.io/machine-secret-uid: {{ $h.machineSecret.uid | quote }}
    lorasis.io/machine-secret-initial-resource-version: {{ $h.machineSecret.resourceVersion | quote }}
    lorasis.io/status-claim-uid: {{ $h.statusClaim.uid | quote }}
spec:
  selector:
    matchLabels: {app.kubernetes.io/name: {{ $name | quote }}}
  updateStrategy:
    type: OnDelete
  template:
    metadata:
      labels: {app.kubernetes.io/name: {{ $name | quote }}}
    spec:
      serviceAccountName: {{ $name }}
      automountServiceAccountToken: false
      hostPID: true
      hostNetwork: true
      dnsPolicy: ClusterFirstWithHostNet
      nodeSelector: {{ toYaml .Values.sensor.nodeSelector | nindent 8 }}
      {{- with .Values.tolerations }}
      tolerations: {{ toYaml . | nindent 8 }}
      {{- end }}
      {{- with .Values.imagePullSecrets }}
      imagePullSecrets: {{ toYaml . | nindent 8 }}
      {{- end }}
      terminationGracePeriodSeconds: 60
      initContainers:
      # Kubernetes Secret projection is a symlink; the producer rejects symlinks.
      # Copy only in this Pod to a root-owned memory file; never expose to signer.
      - name: producer-key-custody
        image: "{{ required "sensor image repository required" .Values.sensor.image.repository }}@{{ required "sensor immutable image digest required" .Values.sensor.image.digest }}"
        imagePullPolicy: IfNotPresent
        command: [sh, -ec]
        args:
        - 'umask 077; test "$(wc -c < /run/lorasis/source-key/key.bin)" -eq 64; cp /run/lorasis/source-key/key.bin /run/lorasis/producer/key.bin; chmod 600 /run/lorasis/producer/key.bin'
        securityContext:
          privileged: false
          runAsUser: 0
          allowPrivilegeEscalation: false
          readOnlyRootFilesystem: true
          capabilities: {drop: [ALL]}
          seccompProfile: {type: RuntimeDefault}
        resources:
          requests: {cpu: 10m, memory: 16Mi}
          limits: {cpu: 100m, memory: 32Mi}
        volumeMounts:
        - {name: source-key, mountPath: /run/lorasis/source-key, readOnly: true}
        - {name: producer-key, mountPath: /run/lorasis/producer}
      - name: hosted-startup-custody
        image: "{{ $h.helperImage.repository }}@{{ $h.helperImage.digest }}"
        imagePullPolicy: IfNotPresent
        command: [python, -I, -B, -m, maintenance_mvp_delivery.tourniquet_projection]
        args: [startup, --source, /run/lorasis/startup-projection, --destination, /run/lorasis/hosted/files, --config-sha256, {{ $h.configurationSha256 | quote }}, --expected-proxy-url, {{ .Values.proxy.https | quote }}]
        securityContext: &stagerSecurity
          privileged: false
          runAsUser: 0
          allowPrivilegeEscalation: false
          readOnlyRootFilesystem: true
          capabilities: {drop: [ALL]}
          seccompProfile: {type: RuntimeDefault}
        resources: &stagerResources
          requests: {cpu: 10m, memory: 32Mi}
          limits: {cpu: 100m, memory: 64Mi}
        volumeMounts:
        - {name: hosted-startup-source, mountPath: /run/lorasis/startup-projection, readOnly: true}
        - {name: hosted-startup-private, mountPath: /run/lorasis/hosted}
      - name: machine-initial-custody
        image: "{{ $h.helperImage.repository }}@{{ $h.helperImage.digest }}"
        imagePullPolicy: IfNotPresent
        command: [python, -I, -B, -m, maintenance_mvp_delivery.tourniquet_projection]
        args: [machine-once, --source, /run/lorasis/machine-projection, --destination, /run/lorasis/machine/files]
        securityContext: *stagerSecurity
        resources: *stagerResources
        volumeMounts:
        - {name: hosted-machine-source, mountPath: /run/lorasis/machine-projection, readOnly: true}
        - {name: hosted-machine-private, mountPath: /run/lorasis/machine}
      containers:
      - name: tourniquet
        image: "{{ .Values.sensor.image.repository }}@{{ .Values.sensor.image.digest }}"
        imagePullPolicy: IfNotPresent
        command: [/usr/bin/tourniquet]
        args: ["--config", "/etc/tourniquet/config.yaml"]
        env:
        - {name: SENSE_PROOF_ENABLED, value: "true"}
        - {name: TQ_HOSTED_CONFIG_FILE, value: /run/lorasis/hosted/files/config.json}
        - {name: SENSE_PRODUCER_KEY_FILE, value: /run/lorasis/producer/key.bin}
        {{- if .Values.customCA.configMapName }}
        - {name: SSL_CERT_FILE, value: /etc/lorasis/ca/ca-bundle.crt}
        {{- end }}
        securityContext:
          privileged: true
          runAsUser: 0
          readOnlyRootFilesystem: true
        startupProbe:
          exec: {command: [wget, -q, -O-, "http://127.0.0.1:8082/health"]}
          periodSeconds: 5
          timeoutSeconds: 5
          failureThreshold: 120
        readinessProbe:
          exec: {command: [wget, -q, -O-, "http://127.0.0.1:8082/health"]}
          periodSeconds: 10
          timeoutSeconds: 5
          failureThreshold: 3
        resources: {{ toYaml .Values.sensor.resources | nindent 10 }}
        volumeMounts:
        - {name: config, mountPath: /etc/tourniquet, readOnly: true}
        - {name: sys, mountPath: /sys, readOnly: true}
        - {name: bpffs, mountPath: /sys/fs/bpf}
        - {name: producer-key, mountPath: /run/lorasis/producer, readOnly: true}
        - {name: hosted-startup-private, mountPath: /run/lorasis/hosted, readOnly: true}
        - {name: hosted-machine-private, mountPath: /run/lorasis/machine, readOnly: true}
        - {name: hosted-status, mountPath: /var/lib/lorasis/tourniquet}
        - {name: tmp, mountPath: /tmp}
        - {name: run, mountPath: /var/run/tourniquet}
        {{- if .Values.customCA.configMapName }}
        - {name: custom-ca, mountPath: /etc/lorasis/ca, readOnly: true}
        {{- end }}
      - name: machine-projection-bridge
        image: "{{ $h.helperImage.repository }}@{{ $h.helperImage.digest }}"
        imagePullPolicy: IfNotPresent
        command: [python, -I, -B, -m, maintenance_mvp_delivery.tourniquet_projection]
        args: [machine-watch, --source, /run/lorasis/machine-projection, --destination, /run/lorasis/machine/files, --poll-seconds, {{ $h.pollSeconds | quote }}, --watch-seconds, {{ $h.watchSeconds | quote }}]
        securityContext: *stagerSecurity
        resources: *stagerResources
        volumeMounts:
        - {name: hosted-machine-source, mountPath: /run/lorasis/machine-projection, readOnly: true}
        - {name: hosted-machine-private, mountPath: /run/lorasis/machine}
      volumes:
      - name: hosted-startup-source
        projected:
          defaultMode: 256
          sources:
          - secret:
              name: {{ $h.startupSecret.name | quote }}
              items:
              - {key: config.json, path: config.json}
              - {key: registration.json, path: registration.json}
              - {key: installation.json, path: installation.json}
              - {key: allowance.json, path: allowance.json}
              - {key: producer-identity.json, path: producer-identity.json}
              - {key: recipient.pem, path: recipient.pem}
      - name: hosted-machine-source
        projected:
          defaultMode: 256
          sources:
          - secret:
              name: {{ $h.machineSecret.name | quote }}
              items: [{key: token, path: token}, {key: lease.json, path: lease.json}]
      - name: hosted-startup-private
        emptyDir: {medium: Memory, sizeLimit: 1Mi}
      - name: hosted-machine-private
        emptyDir: {medium: Memory, sizeLimit: 1Mi}
      - name: hosted-status
        persistentVolumeClaim: {claimName: {{ $h.statusClaim.name | quote }}}
      - name: config
        configMap: {name: {{ required "reviewed sensor configuration required" .Values.sensor.configMapName | quote }}}
      - name: source-key
        secret:
          secretName: {{ required "existing producer key Secret required" .Values.sensor.producerKeySecret | quote }}
          defaultMode: 256
          items: [{key: key.bin, path: key.bin}]
      - name: producer-key
        emptyDir: {medium: Memory, sizeLimit: 1Mi}
      - name: sys
        hostPath: {path: /sys, type: Directory}
      - name: bpffs
        hostPath: {path: /sys/fs/bpf, type: Directory}
      - name: tmp
        emptyDir: {sizeLimit: 64Mi}
      - name: run
        emptyDir: {medium: Memory, sizeLimit: 1Mi}
      {{- if .Values.customCA.configMapName }}
      - name: custom-ca
        configMap:
          name: {{ .Values.customCA.configMapName | quote }}
          items: [{key: {{ .Values.customCA.key | quote }}, path: ca-bundle.crt}]
      {{- end }}
{{- end }}
