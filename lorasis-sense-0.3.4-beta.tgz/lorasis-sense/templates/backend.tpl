{{- include "sense.validate" . }}
{{/* evidence backend and database custody remain hosted; historical source preserved in bound input. */}}
