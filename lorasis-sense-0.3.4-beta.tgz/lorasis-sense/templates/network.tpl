{{- if and .Values.namespace.enabled (ne .Values.namespace.observer.phase "INITIALIZE") }}
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: {{ .Release.Name }}-observer-hosted
  namespace: {{ .Release.Namespace }}
spec:
  podSelector:
    matchExpressions:
    - key: app.kubernetes.io/name
      operator: In
      values: ["{{ .Release.Name }}-observer", {{ printf "%s-enrollment" .Release.Name | trunc 63 | trimSuffix "-" | quote }}]
  policyTypes: [Ingress, Egress]
  ingress: []
  egress:
  - to:
    {{- range .Values.namespace.apiServerCIDRs }}
    - ipBlock: {cidr: {{ . | quote }}}
    {{- end }}
    ports: [{protocol: TCP, port: 6443}, {protocol: TCP, port: 443}]
  - to:
    {{- if .Values.proxy.https }}
    {{- range .Values.proxy.destinationCIDRs }}
    - ipBlock: {cidr: {{ . | quote }}}
    {{- end }}
    ports: [{protocol: TCP, port: {{ regexFind "[0-9]+$" .Values.proxy.https | int }}}]
    {{- else }}
    {{- range .Values.namespace.hosted.destinationCIDRs }}
    - ipBlock: {cidr: {{ . | quote }}}
    {{- end }}
    ports: [{protocol: TCP, port: {{ .Values.namespace.hosted.port }}}]
    {{- end }}
  - to:
    - namespaceSelector:
        matchLabels: {kubernetes.io/metadata.name: openshift-dns}
    ports: [{protocol: UDP, port: 53}, {protocol: TCP, port: 53}, {protocol: UDP, port: 5353}, {protocol: TCP, port: 5353}]
{{- end }}
