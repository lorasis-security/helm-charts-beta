{{- include "sense.validate" . }}
{{/* signed evidence ingress remains hosted; historical source preserved in bound input. */}}
