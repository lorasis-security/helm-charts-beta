{{- $observer := .Values.namespace.observer }}
{{- $credential := $observer.installationCredentialSecret | default dict }}
{{- $name := $credential.name | default "" }}
{{- $key := $credential.key | default "" }}
{{- $installer := $observer.machineInstaller }}
{{- if and .Values.namespace.enabled (eq $observer.phase "ACTIVATE") }}
{{- if or (not .Values.namespace.enabled) (ne $observer.clusterReadAccess.mode "EXISTING") }}
{{- fail "machine installation requires exact reviewed namespace declaration" }}
{{- end }}
{{- if or (not $name) (not $key) (not $installer.serviceAccountName) (not $installer.protectedTargetSecret.name) (not $installer.protectedTargetSecret.key) }}
{{- fail "machine installation requires separate existing installer and complete protected file references" }}
{{- end }}
{{- if eq $installer.serviceAccountName (printf "%s-observer" .Release.Name) }}
{{- fail "installer ServiceAccount must be separate from runtime observer" }}
{{- end }}
{{- $custody := list $observer.identitySecret $observer.machineCredentialSecret.name $observer.machineCASecret.name $name $installer.protectedTargetSecret.name }}
{{- if ne (len (uniq $custody)) (len $custody) }}
{{- fail "source identity runtime machine CA envelope and protected target Secrets must be distinct" }}
{{- end }}
{{- if ne $observer.observedNamespace .Release.Namespace }}
{{- fail "installer target namespace must equal the exact release namespace" }}
{{- end }}
{{- if not (regexMatch "^[a-z0-9][a-z0-9.-]{0,62}$" $observer.machineCredentialSecret.name) }}
{{- fail "machine target Secret name must satisfy the actual handoff consumer" }}
{{- end }}
{{- $referenceID := printf "%s:%s:%s" .Release.Name $name $key | sha256sum | trunc 12 }}
# Proposed grants for an independently authorised preexisting installer SA only.
# No Secret or SA is created here; no grants are attached to runtime observer.
apiVersion: rbac.authorization.k8s.io/v1
kind: Role
metadata:
  name: {{ .Release.Name }}-machine-installer
  namespace: {{ .Release.Namespace }}
rules:
- apiGroups: [""]
  resources: [secrets]
  resourceNames: [{{ $observer.machineCredentialSecret.name | quote }}]
  verbs: [get, patch]
---
apiVersion: rbac.authorization.k8s.io/v1
kind: RoleBinding
metadata:
  name: {{ .Release.Name }}-machine-installer
  namespace: {{ .Release.Namespace }}
roleRef: {apiGroup: rbac.authorization.k8s.io, kind: Role, name: "{{ .Release.Name }}-machine-installer"}
subjects:
- {kind: ServiceAccount, name: {{ $installer.serviceAccountName | quote }}, namespace: {{ .Release.Namespace | quote }}}
---
apiVersion: v1
kind: Pod
metadata:
  name: {{ printf "%s-enroll-%s" (.Release.Name | trunc 40 | trimSuffix "-") $referenceID | quote }}
  namespace: {{ .Release.Namespace }}
  labels:
    app.kubernetes.io/name: {{ printf "%s-enrollment" .Release.Name | trunc 63 | trimSuffix "-" | quote }}
  annotations:
    lorasis.io/initialization-readback-sha256: {{ $observer.signingCheckpoint.initializationReadbackSha256 | quote }}
    lorasis.io/configuration-sha256: {{ .Values.namespace.hosted.configurationSha256 | quote }}
spec:
  activeDeadlineSeconds: 120
  serviceAccountName: {{ $installer.serviceAccountName | quote }}
  automountServiceAccountToken: false
  restartPolicy: Never
  terminationGracePeriodSeconds: 30
  nodeSelector: {{ toYaml .Values.nodeSelector | nindent 4 }}
  {{- with .Values.imagePullSecrets }}
  imagePullSecrets: {{ toYaml . | nindent 4 }}
  {{- end }}
  {{- with .Values.tolerations }}
  tolerations: {{ toYaml . | nindent 4 }}
  {{- end }}
  securityContext:
    runAsNonRoot: true
    runAsUser: {{ int .Values.namespace.runAsUser }}
    runAsGroup: {{ int .Values.namespace.runAsGroup }}
    fsGroup: {{ int .Values.namespace.fsGroup }}
    seccompProfile: {type: RuntimeDefault}
  containers:
  - name: observer-enrollment
    image: "{{ $observer.image.repository }}@{{ $observer.image.digest }}"
    imagePullPolicy: IfNotPresent
    command: [python, -I, -B, -m, maintenance_mvp_delivery.resource_observer_machine_activation]
    args: [--configuration, /etc/observer/configuration.json, --enrollment-file, /var/run/observer-enrollment/credential.json, --target-file, /var/run/observer-installer/target.json, --binding-file, /var/run/observer-identity/install-binding.json, --source-key-file, /var/run/observer-identity/source.key, --renewal-pin-file, /var/run/observer-identity/service-credentials.sha256]
    terminationMessagePolicy: File
    securityContext:
      allowPrivilegeEscalation: false
      readOnlyRootFilesystem: true
      capabilities: {drop: [ALL]}
    resources: {{ toYaml $observer.resources | nindent 6 }}
    volumeMounts:
    - {name: config, mountPath: /etc/observer, readOnly: true}
    - {name: identity, mountPath: /var/run/observer-identity, readOnly: true}
    - {name: enrollment, mountPath: /var/run/observer-enrollment, readOnly: true}
    - {name: protected-target, mountPath: /var/run/observer-installer, readOnly: true}
    - {name: installer-api, mountPath: /var/run/observer-installer-api, readOnly: true}
    - {name: tmp, mountPath: /tmp}
  volumes:
  - name: config
    configMap: {name: {{ $observer.configurationConfigMap | quote }}}
  - name: identity
    projected:
      defaultMode: 288
      sources:
      - secret:
          name: {{ $observer.identitySecret | quote }}
          items: [{key: source.key, path: source.key}, {key: service-credentials.sha256, path: service-credentials.sha256}, {key: install-binding.json, path: install-binding.json}]
      - secret:
          name: {{ $observer.machineCASecret.name | quote }}
          items: [{key: {{ $observer.machineCASecret.key | quote }}, path: machine-ca.crt}]
  - name: enrollment
    secret:
      secretName: {{ $name | quote }}
      defaultMode: 288
      items: [{key: {{ $key | quote }}, path: credential.json}]
  - name: protected-target
    secret:
      secretName: {{ $installer.protectedTargetSecret.name | quote }}
      defaultMode: 288
      items: [{key: {{ $installer.protectedTargetSecret.key | quote }}, path: target.json}]
  - name: installer-api
    projected:
      defaultMode: 288
      sources:
      - serviceAccountToken: {path: token, expirationSeconds: 3600}
      - configMap:
          name: kube-root-ca.crt
          items: [{key: ca.crt, path: ca.crt}]
  - {name: tmp, emptyDir: {medium: Memory, sizeLimit: 16Mi}}
{{- end }}
