{{- include "sense.validate" . }}
{{/* debug payload exporter is not an admitted edge telemetry pipeline; historical source preserved in bound input. */}}
