{{- define "sense.validate" -}}
{{- if .Values.proxy.https }}
{{- if or (not (regexMatch "^http://[a-z0-9]([a-z0-9.-]*[a-z0-9])?:[1-9][0-9]{0,4}$" .Values.proxy.https)) (gt (regexFind "[0-9]+$" .Values.proxy.https | int) 65535) (empty .Values.proxy.destinationCIDRs) }}
{{- fail "explicit unauthenticated HTTP CONNECT URL and reviewed proxy destination CIDRs required" }}
{{- end }}
{{- else if .Values.proxy.destinationCIDRs }}
{{- fail "proxy destination CIDRs require an explicit proxy URL" }}
{{- end }}
{{- if or .Values.backend.enabled .Values.collector.enabled .Values.signedIngress.enabled .Values.sensor.lifecycle.enabled }}
{{- fail "hosted customer contract forbids local evidence backend verifier debug collector ingress and lifecycle payload PVC" }}
{{- end }}
{{- $phase := .Values.namespace.observer.phase }}
{{- if ne .Values.namespace.enabled (ne $phase "INERT") }}
{{- fail "observer enabled and explicit phase must agree; defaults are inert" }}
{{- end }}
{{- if .Values.namespace.enabled }}
{{- $o := .Values.namespace.observer }}
{{- $h := .Values.namespace.hosted }}
{{- $c := $o.signingCheckpoint }}
{{- if or (not .Values.namespace.runAsGroup) (ne (int .Values.namespace.runAsGroup) (int .Values.namespace.fsGroup)) }}
{{- fail "checkpoint effective group must equal projection fsGroup" }}
{{- end }}
{{- if not (regexMatch "^[a-f0-9]{64}$" $c.bindingSha256) }}
{{- fail "independently checked signing binding required" }}
{{- end }}
{{- if eq $c.bindingSha256 $h.installationBinding.sha256 }}
{{- fail "signing binding is not the installation binding digest" }}
{{- end }}
{{- if eq $phase "INITIALIZE" }}
{{- if or (not (regexMatch "^[a-f0-9]{64}$" $c.freshStreamAuthorizationSha256)) $c.initializationReadbackSha256 $o.activationReadbackSha256 }}
{{- fail "initialization requires independent fresh stream authorization and no prior completion; never reset or retry" }}
{{- end }}
{{- else }}
{{- if not (regexMatch "^[a-f0-9]{64}$" $c.initializationReadbackSha256) }}
{{- fail "initialization readback reference required before activation or collection" }}
{{- end }}
{{- end }}
{{- if eq $phase "ACTIVATE" }}
{{- if or (ne $o.machineInstaller.admission "EXPLICIT_PHASE") $o.activationReadbackSha256 (empty $o.installationCredentialSecret.name) (empty $o.installationCredentialSecret.key) }}
{{- fail "activation requires explicit phase and complete envelope; no prior completion or retry" }}
{{- end }}
{{- else if has $phase (list "COLLECT" "PAUSED") }}
{{- if not (regexMatch "^[a-f0-9]{64}$" $o.activationReadbackSha256) }}
{{- fail "confirmed activation readback reference required before collection" }}
{{- end }}
{{- end }}
{{- if and (eq $phase "COLLECT") (not .Values.sensor.enabled) }}
{{- fail "customer collection requires the existing single Tourniquet declaration" }}
{{- end }}
{{- if or (ne $o.runtime.version "lorasis-observer-runtime/v3") (ne $o.signingCheckpoint.mode "EXISTING_PRIVATE_SUBPATH") }}
{{- fail "observer v3 closed memory profile and explicit existing private checkpoint required" }}
{{- end }}
{{- $names := list $o.identitySecret $o.machineCredentialSecret.name $o.machineCASecret.name }}
{{- if ne (len (uniq $names)) (len $names) }}
{{- fail "producer signing machine access and machine CA Secret custody must be distinct" }}
{{- end }}
{{- if and $o.installationCredentialSecret.name (has $o.installationCredentialSecret.name $names) }}
{{- fail "bootstrap Secret must be independent of signing and runtime credentials" }}
{{- end }}
{{- if and .Values.sensor.enabled (has .Values.sensor.producerKeySecret $names) }}
{{- fail "Tourniquet key must be independent of resource observer custody" }}
{{- end }}
{{- if or (not (regexMatch "^https://[a-z0-9.-]+(:[1-9][0-9]{0,4})?$" $h.backendOrigin)) (and (not .Values.proxy.https) (not $h.destinationCIDRs)) }}
{{- fail "exact hosted HTTPS origin CA pin and reviewed destination addresses required" }}
{{- end }}
{{- end }}
{{- end -}}
