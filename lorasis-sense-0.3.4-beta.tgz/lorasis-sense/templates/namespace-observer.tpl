{{- $observer := .Values.namespace.observer }}
{{- $collection := $observer.collection | default dict }}
{{- $clusterAccess := $observer.clusterReadAccess | default dict }}
{{- if or .Values.namespace.enabled (eq $clusterAccess.mode "ADMIN_PACKET") }}
{{- if or (ne $observer.observedNamespace .Release.Namespace) (gt (len $observer.observedNamespace) 63) (not (regexMatch "^[a-z0-9]([-a-z0-9]*[a-z0-9])?$" $observer.observedNamespace)) }}
{{- fail "observer requires the exact release namespace" }}
{{- end }}
{{- if not (has $collection.resource (list "configmaps" "deployments" "pods")) }}
{{- fail "observer collection resource must be explicitly selected" }}
{{- end }}
{{- if not (has $collection.mode (list "EXACT_NAMES" "ALL_IN_NAMESPACE")) }}
{{- fail "observer collection mode must be explicitly selected" }}
{{- end }}
{{- if not (kindIs "slice" $collection.exactNames) }}
{{- fail "observer exactNames must be a list" }}
{{- end }}
{{- if eq $collection.mode "EXACT_NAMES" }}
{{- if or (eq $collection.resource "pods") (ne (len $collection.exactNames) 1) }}
{{- fail "exact selection requires one ConfigMap or Deployment name; Pod membership cannot be filtered" }}
{{- end }}
{{- range $name := $collection.exactNames }}
{{- if or (gt (len $name) 253) (not (regexMatch "^[a-z0-9]([-a-z0-9]*[a-z0-9])?(\\.[a-z0-9]([-a-z0-9]*[a-z0-9])?)*$" $name)) }}
{{- fail "observer exact name is invalid" }}
{{- end }}
{{- end }}
{{- else if ne (len $collection.exactNames) 0 }}
{{- fail "namespace wide observation cannot carry exactNames" }}
{{- end }}
{{- end }}
{{- if eq $clusterAccess.mode "ADMIN_PACKET" }}
{{- if or .Values.namespace.enabled .Values.backend.enabled .Values.collector.enabled .Values.signedIngress.enabled .Values.sensor.enabled .Values.sensor.lifecycle.enabled }}
{{- fail "administrator RBAC packet requires all workloads disabled" }}
{{- end }}
# Administrator packet only. Review and apply separately from application installation.
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRole
metadata:
  name: {{ .Release.Namespace }}-{{ .Release.Name }}-observer-namespace
  annotations: {helm.sh/resource-policy: keep}
rules:
- apiGroups: [""]
  resources: [namespaces]
  resourceNames: [{{ $observer.observedNamespace | quote }}]
  verbs: [get]
- nonResourceURLs: ["/api/v1"{{ if eq $collection.resource "deployments" }}, "/apis/apps/v1"{{ end }}]
  verbs: [get]
---
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRoleBinding
metadata:
  name: {{ .Release.Namespace }}-{{ .Release.Name }}-observer-namespace
  annotations: {helm.sh/resource-policy: keep}
roleRef: {apiGroup: rbac.authorization.k8s.io, kind: ClusterRole, name: "{{ .Release.Namespace }}-{{ .Release.Name }}-observer-namespace"}
subjects:
- {kind: ServiceAccount, name: "{{ .Release.Name }}-observer", namespace: {{ .Release.Namespace | quote }}}
{{- else if .Values.namespace.enabled }}
{{- $checkpoint := $observer.signingCheckpoint }}
{{- if or (empty $checkpoint.claim.name) (empty $checkpoint.claim.uid) }}
{{- fail "observer checkpoint requires one exact existing claim name and UID" }}
{{- end }}
{{- if and .Values.sensor.enabled (eq $checkpoint.claim.name .Values.sensor.hosted.statusClaim.name) }}
{{- fail "observer signing checkpoint must be separate from Tourniquet status claim" }}
{{- end }}
{{- if or (ne $clusterAccess.mode "EXISTING") (ne (len $clusterAccess.reviewSha256) 64) (not (regexMatch "^[a-f0-9]{64}$" $clusterAccess.reviewSha256)) }}
{{- fail "active observer requires an existing namespace identity and discovery access review reference" }}
{{- end }}
apiVersion: v1
kind: ServiceAccount
metadata:
  name: {{ .Release.Name }}-observer
  namespace: {{ .Release.Namespace }}
automountServiceAccountToken: false
{{- if has $observer.phase (list "COLLECT" "PAUSED") }}
---
apiVersion: rbac.authorization.k8s.io/v1
kind: Role
metadata:
  name: {{ .Release.Name }}-observer-read
  namespace: {{ .Values.namespace.observer.observedNamespace }}
rules:
- apiGroups: [{{ ternary "apps" "" (eq $collection.resource "deployments") | quote }}]
  resources: [{{ $collection.resource | quote }}]
  verbs: [get, list, watch]
  {{- if eq $collection.mode "EXACT_NAMES" }}
  resourceNames: {{ $collection.exactNames | toJson }}
  {{- end }}
---
apiVersion: rbac.authorization.k8s.io/v1
kind: RoleBinding
metadata:
  name: {{ .Release.Name }}-observer-read
  namespace: {{ .Values.namespace.observer.observedNamespace }}
roleRef: {apiGroup: rbac.authorization.k8s.io, kind: Role, name: "{{ .Release.Name }}-observer-read"}
subjects:
- {kind: ServiceAccount, name: "{{ .Release.Name }}-observer", namespace: {{ .Release.Namespace | quote }}}
---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: {{ .Release.Name }}-observer
  namespace: {{ .Release.Namespace }}
spec:
  replicas: {{ ternary 0 1 (eq $observer.phase "PAUSED") }}
  strategy: {type: Recreate}
  selector:
    matchLabels: {app.kubernetes.io/name: "{{ .Release.Name }}-observer"}
  template:
    metadata:
      labels: {app.kubernetes.io/name: "{{ .Release.Name }}-observer"}
      # Independently refreshed metadata reference, not a kubelet CAS or initialization.
      annotations:
        lorasis.io/signing-checkpoint-claim-name: {{ $checkpoint.claim.name | quote }}
        lorasis.io/signing-checkpoint-claim-uid: {{ $checkpoint.claim.uid | quote }}
        lorasis.io/signing-binding-sha256: {{ $checkpoint.bindingSha256 | quote }}
        lorasis.io/initialization-readback-sha256: {{ $checkpoint.initializationReadbackSha256 | quote }}
        lorasis.io/activation-readback-sha256: {{ $observer.activationReadbackSha256 | quote }}
        lorasis.io/configuration-sha256: {{ .Values.namespace.hosted.configurationSha256 | quote }}
    spec:
      serviceAccountName: {{ .Release.Name }}-observer
      automountServiceAccountToken: false
      terminationGracePeriodSeconds: 60
      nodeSelector: {{ toYaml .Values.nodeSelector | nindent 8 }}
      {{- with .Values.imagePullSecrets }}
      imagePullSecrets: {{ toYaml . | nindent 8 }}
      {{- end }}
      {{- with .Values.tolerations }}
      tolerations: {{ toYaml . | nindent 8 }}
      {{- end }}
      securityContext:
        runAsNonRoot: true
        {{- if .Values.namespace.enabled }}
        runAsUser: {{ int .Values.namespace.runAsUser }}
        runAsGroup: {{ int .Values.namespace.runAsGroup }}
        fsGroup: {{ int .Values.namespace.fsGroup }}
        fsGroupChangePolicy: OnRootMismatch
        {{- end }}
        seccompProfile: {type: RuntimeDefault}
      containers:
      - name: namespace-observer
        image: "{{ .Values.namespace.observer.image.repository }}@{{ .Values.namespace.observer.image.digest }}"
        imagePullPolicy: IfNotPresent
        command: [python, -m, maintenance_mvp_delivery.resource_observer_main]
        args: [--configuration, /etc/observer/configuration.json]
        securityContext:
          allowPrivilegeEscalation: false
          readOnlyRootFilesystem: true
          capabilities: {drop: [ALL]}
        resources: {{ toYaml .Values.namespace.observer.resources | nindent 10 }}
        startupProbe:
          httpGet: {path: /health/live, port: 9090}
          failureThreshold: 60
          periodSeconds: 5
        readinessProbe:
          httpGet: {path: /health/ready, port: 9090}
          periodSeconds: 5
        volumeMounts:
        - {name: config, mountPath: /etc/observer, readOnly: true}
        - {name: signing-checkpoint, mountPath: /var/lib/observer-signing, subPath: {{ printf "checkpoint-%s" $checkpoint.bindingSha256 | quote }}}
        - {name: identity, mountPath: /var/run/observer-identity, readOnly: true}
        - {name: api-identity, mountPath: /var/run/secrets/kubernetes.io/serviceaccount, readOnly: true}
        - {name: tmp, mountPath: /tmp}
      volumes:
      - name: signing-checkpoint
        persistentVolumeClaim: {claimName: {{ $checkpoint.claim.name | quote }}}
      - name: config
        configMap: {name: {{ .Values.namespace.observer.configurationConfigMap | quote }}}
      - name: identity
        projected:
          defaultMode: 288
          sources:
          - secret:
              name: {{ $observer.identitySecret | quote }}
              items: [{key: source.key, path: source.key}, {key: service-credentials.sha256, path: service-credentials.sha256}]
          - secret:
              name: {{ $observer.machineCredentialSecret.name | quote }}
              items: [{key: {{ $observer.machineCredentialSecret.key | quote }}, path: machine-credential.json}]
          - secret:
              name: {{ $observer.machineCASecret.name | quote }}
              items: [{key: {{ $observer.machineCASecret.key | quote }}, path: machine-ca.crt}]
      - name: api-identity
        projected:
          defaultMode: 288
          sources:
          - serviceAccountToken: {path: token, expirationSeconds: 3600}
          - configMap:
              name: kube-root-ca.crt
              items: [{key: ca.crt, path: ca.crt}]
      - {name: tmp, emptyDir: {medium: Memory, sizeLimit: 16Mi}}
{{- end }}
{{- end }}
