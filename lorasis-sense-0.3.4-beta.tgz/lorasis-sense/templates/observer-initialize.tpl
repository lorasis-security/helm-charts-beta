{{- if and .Values.namespace.enabled (eq .Values.namespace.observer.phase "INITIALIZE") }}
{{- $o := .Values.namespace.observer }}
{{- $c := $o.signingCheckpoint }}
# One explicit attempt. No Job controller, hook, initContainer or runtime retry.
# References document independent authorization; Helm cannot establish virginity.
apiVersion: v1
kind: Pod
metadata:
  name: {{ printf "%s-initialize-%s" (.Release.Name | trunc 35 | trimSuffix "-") ($c.bindingSha256 | trunc 12) | quote }}
  namespace: {{ .Release.Namespace }}
  labels: {app.kubernetes.io/name: "{{ .Release.Name }}-initialize"}
  annotations:
    lorasis.io/signing-checkpoint-claim-name: {{ $c.claim.name | quote }}
    lorasis.io/signing-checkpoint-claim-uid: {{ $c.claim.uid | quote }}
    lorasis.io/signing-binding-sha256: {{ $c.bindingSha256 | quote }}
    lorasis.io/fresh-stream-authorization-sha256: {{ $c.freshStreamAuthorizationSha256 | quote }}
spec:
  serviceAccountName: {{ .Release.Name }}-observer
  automountServiceAccountToken: false
  restartPolicy: Never
  activeDeadlineSeconds: 120
  terminationGracePeriodSeconds: 30
  nodeSelector: {{ toYaml .Values.nodeSelector | nindent 4 }}
  {{- with .Values.imagePullSecrets }}
  imagePullSecrets: {{ toYaml . | nindent 4 }}
  {{- end }}
  {{- with .Values.tolerations }}
  tolerations: {{ toYaml . | nindent 4 }}
  {{- end }}
  securityContext:
    runAsNonRoot: true
    runAsUser: {{ int .Values.namespace.runAsUser }}
    runAsGroup: {{ int .Values.namespace.runAsGroup }}
    fsGroup: {{ int .Values.namespace.fsGroup }}
    fsGroupChangePolicy: OnRootMismatch
    seccompProfile: {type: RuntimeDefault}
  containers:
  - name: checkpoint-initialize
    image: "{{ $o.image.repository }}@{{ $o.image.digest }}"
    imagePullPolicy: IfNotPresent
    command: [python, -I, -B, -m, maintenance_mvp_delivery.checkpoint_initialize]
    args: [--binding-sha256, {{ $c.bindingSha256 | quote }}]
    terminationMessagePolicy: File
    securityContext:
      allowPrivilegeEscalation: false
      readOnlyRootFilesystem: true
      capabilities: {drop: [ALL]}
    resources: {{ toYaml $o.resources | nindent 6 }}
    volumeMounts:
    - {name: signing-checkpoint, mountPath: /var/lib/observer-signing, subPath: {{ printf "checkpoint-%s" $c.bindingSha256 | quote }}}
  volumes:
  - name: signing-checkpoint
    persistentVolumeClaim: {claimName: {{ $c.claim.name | quote }}}
---
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: {{ .Release.Name }}-initialize-deny
  namespace: {{ .Release.Namespace }}
spec:
  podSelector:
    matchLabels: {app.kubernetes.io/name: "{{ .Release.Name }}-initialize"}
  policyTypes: [Ingress, Egress]
  ingress: []
  egress: []
{{- end }}
