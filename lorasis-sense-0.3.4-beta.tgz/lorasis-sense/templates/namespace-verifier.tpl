{{- include "sense.validate" . }}
{{/* independent server verifier remains hosted, not an edge workload; historical source preserved in bound input. */}}
