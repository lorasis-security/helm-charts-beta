{{/* Copy projected inputs once into effective UID owned regular files. */}}
{{- define "sense.privateCopy" -}}
import os,pathlib,re,sys
src,dst=map(pathlib.Path,sys.argv[1:3])
os.umask(0o077)
dst.mkdir(mode=0o700,parents=True,exist_ok=True)
os.chmod(dst,0o700)
entries=[p for p in src.iterdir() if not p.name.startswith('..')]
if not 0<len(entries)<=128: raise ValueError('private_input_count')
total=0
for p in entries:
 if re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]{0,127}',p.name) is None: raise ValueError('private_input_name')
 with p.open('rb') as f: raw=f.read(1048577)
 total+=len(raw)
 if not 0<len(raw)<=1048576 or total>16777216: raise ValueError('private_input_bound')
 fd=os.open(dst/p.name,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
 with os.fdopen(fd,'wb') as f: f.write(raw)
{{- end -}}
