# Lorasis Sense

**BETA**

**FOR TECHNICAL REVIEW. NOT YET QUALIFIED FOR DEPLOYMENT.**

Chart version: `0.3.4-beta`. Application version: `0.2.0`.
`appVersion` is retained metadata, not a binding to a qualified image.
Beta is release branding, not deployment qualification or installation authority.
Defaults are inert and start no workloads. Do not install this chart on the
basis of catalogue availability, successful rendering or syntactically valid
approval references.

## Scope

This is a metadata-and-documentation derivative of chart
`0.3.4-unqualified`. Functional templates, values, schema, image identities,
permissions, validation predicates and safety gates are unchanged.
It is not a redesigned chart or an adopted delivery candidate.

The chart can render the Tourniquet sensor and resource observer. Backend,
signed-ingress and collector template files are refusal-only placeholders;
enabling those components is rejected. The retained collector image reference
does not make the collector usable. Most image references are intentionally
empty. The chart does not supply application images, Python wheels,
companion bundles, credentials, enrollment authority or a qualified installation.
An available filename or module name does not establish image inclusion.

`PHASES.md` documents the separate observer effects and mandatory independent
checks. Treat its commands as interface references, not instructions to execute
without separate authorization and qualified inputs.

## Required platform

The chart's security and DNS assumptions require **OpenShift**, including
independently reviewed SCC admission and DNS in the `openshift-dns` namespace.
The Kubernetes version constraint alone does not establish compatibility.
The chart does not detect or refuse all non-OpenShift targets: without SCC
admission, sensor privilege is subject only to the other cluster's admission
policy, and the observer DNS rule would not match a conventional DNS namespace.
Do not treat successful rendering as permission to use another platform.

## Installation-security boundaries

- Helm values contain references and digests, never Secret contents or private
  keys. External owners provision, verify and renew protected inputs separately.
  Reference strings and declaration booleans do not establish their authority.
- The sensor requires host networking, host PID visibility, root execution and
  privilege. `admin/sensor-scc.yaml.gotmpl` is a separate administrator review
  input, not an automatically installed SCC or permission to grant privileges.
  No chart rendering proves SELinux, `/proc`, host integrity or key isolation.
- Observer initialization and activation are standalone `restartPolicy: Never`
  Pods, not Jobs or Helm hooks. They still require reconciliation after unknown
  effects; manual retries, rollback or reinstall can repeat irreversible effects.
- Collection uses one observer replica with Recreate. Neither Recreate, RWO nor
  a single-node selector proves that an old owner has stopped on an unreachable
  node. Independently verify owner release before advancing phases.
- Existing claims and prepared signing/status subtrees retain their custody,
  ownership, durability, first-use and recovery requirements. Never initialize
  on restart, delete retained state to recover, alias independent claims, or
  add a root repair container to force a pass.
- The backend, database, verifier and original-evidence custody remain hosted.
  Sensor-local status is bounded control state, not payload or evidence storage.
- No image security clearance, issuer readiness, mounted custody qualification,
  authenticated target readback or end-to-end evidence delivery is established
  by this publication. Outstanding image security and module-inclusion checks
  remain activation blockers.

### RBAC and administrator packet

| Grant | When rendered | Scope and effect |
|---|---|---|
| Sensor Role/RoleBinding | Sensor enabled | Namespaced grant to its ServiceAccount to `use` the named OpenShift SCC; the SCC itself is not created by this chart. |
| Observer Role/RoleBinding | COLLECT and PAUSED | Namespaced `get/list/watch` on the selected resource; exact-name restrictions when selected. `ALL_IN_NAMESPACE` includes every selected ConfigMap or Pod spec in the namespace. |
| Installer Role/RoleBinding | ACTIVATE | Namespaced `get/patch` on exactly the preexisting machine Secret, assigned to the distinct installer ServiceAccount. |
| Administrator ClusterRole/ClusterRoleBinding | `clusterReadAccess.mode: ADMIN_PACKET` | Cluster-scoped `get` on the selected namespace and API discovery URLs `/api/v1` and, where selected, `/apis/apps/v1`. Both carry `helm.sh/resource-policy: keep`. |

`ADMIN_PACKET` starts no workloads, but it **does grant cluster-scoped access**.
Its "review separately" comment is not an enforcement barrier: using this value
in `helm install` or `helm upgrade` applies the grants, and uninstall retains
them. Never use `ADMIN_PACKET` in an application install. Render for separate
administrator review only. Use the same application release name and namespace
when preparing the packet so its ServiceAccount binding matches the application.
Any separately authorized application or removal of those grants requires its
own target and lifecycle checks.

### Sensor footprint and declaration gates

The privileged sensor mounts host `/sys` read-only and `/sys/fs/bpf` read-write.
Its privileged container has no seccomp profile. Health probes address
host-network port `8082`. An exact `kubernetes.io/hostname` selector limits the
sensor to one node, not whole-cluster coverage. Global `tolerations` and
`imagePullSecrets` also affect this privileged DaemonSet and require review.
The SCC review input permits broader hostPath/security settings than an
individual Pod may use; it is not a least-privilege certification.

All six `sensor.hosted.gates` default false and must reflect independent evidence,
not a desire to make the chart render:

- `independentIssuerReady`: independently qualified issuer and enrollment.
- `helperImageContainsModule`: exact immutable helper image contains the module.
- `imageSecurityQualified`: applicable image security checks have passed.
- `mountedCustodyQualified`: mounted key/configuration/credential custody qualified.
- `statusOwnershipQualified`: exact persistent status ownership/recovery qualified.
- `administratorReviewed`: administrator has reviewed the actual target permissions.

These declarations are not verified receipts. `sensor.scc.reviewSha256` is
recorded as an annotation, not compared with the actual live SCC.

## Protected startup and renewable credentials

The sensor invokes `maintenance_mvp_delivery.tourniquet_projection` using the
separately selected immutable helper image. No usable image containing this
module is established by the chart.

The immutable startup Secret is distinct from the renewable machine Secret.
Startup keys are `config.json`, `registration.json`, `installation.json`,
`allowance.json`, `producer-identity.json` and `recipient.pem`.
The startup helper checks the independently supplied configuration digest before
dependent private reads. It stages regular files rather than passing projected
Secret symlinks directly to the hosted reader.

The renewable Secret has the fixed `token` and `lease.json` keys. Its external
owner must renew the pair in one Secret update. The copy helper neither issues
nor signs credentials and has no Secret API grants. The producer signing key
remains in separate custody and is not mounted into these copy helpers.
Startup and machine memories are read-only to the sensor.

The helper pins projected generations, checks pair coherence and publishes
regular private files under its held owner lock. Token and lease publication
is not one filesystem transaction: an intermediate pair can refuse. The
consumer's independent signature, identity, expiry and repeated pair checks
remain required. A healthy copy loop is not issuer or delivery qualification.
Some custody/publication failures latch `.STOP`; restarting the helper does not
authorize recovery. Recreating the Pod loses memory state, not the independent
allowance, control and ownership prerequisites. Same-UID writers or an untrusted
host are not cryptographically isolated by these filesystem checks.

Secret UID/resourceVersion and claim annotations record references only.
Kubelet projection does not turn them into runtime compare-and-swap checks.
The authorized owner must verify the exact live namespace, Secret inventory,
immutability, target identities and prepared claims before activation.

## Optional proxy route

`proxy.https` is a plain HTTP CONNECT proxy URL for HTTPS destinations, for
example `http://proxy.example.test:8080`. Credentials, paths, queries,
fragments, SOCKS and intercepted TLS are not supported. `proxy.http` remains
empty; `proxy.noProxy` is retained but is not consumed for route selection.
No ambient `HTTPS_PROXY` or `NO_PROXY` selects this route.

The exact URL must match independently pinned sensor and observer configuration.
Set `proxy.destinationCIDRs` to independently reviewed proxy addresses, not
blanket egress. Observer/enrollment hosted egress uses the selected proxy;
Kubernetes API and enrollment Secret operations retain direct API/DNS rules.
The sensor uses host networking, so observer NetworkPolicy does not establish
node egress restrictions. Empty proxy is the explicit direct default.
The current values schema still requires `namespace.hosted.destinationCIDRs`
for active observer configuration even with a proxy. That retained schema
requirement is not a direct-egress authorization or proof of proxy qualification.
Real TLS, hostname, authentication and CONNECT qualification remain required.

## Pause, rollback and removal

Use `PAUSED` with the same release, namespace, old observer values and sensor
settings. Verify actual observer termination, drain outcome, ownership release
and coverage gaps. ConfigMap and workload collections are sequential, not
concurrent; historical evidence must not be presented as current coverage.
`PAUSED` stops only the observer. The privileged sensor remains running.
The sensor DaemonSet uses `OnDelete`: Helm upgrades and rollbacks do not replace
existing sensor Pods, so they can keep the old specification until separately
authorized Pod replacement. Do not infer running image/spec identity from the
latest Helm values.

Rollback, uninstall/reinstall, cleared receipt fields and forced replacement
are not permission to repeat initialization or activation. Stop on an unknown
effect and reconcile it with the independent owner. Retain signing checkpoints,
status, keys, original evidence and readbacks. Independently owned ConfigMaps,
Secrets, claims and administrator grants have separate lifecycle authority;
chart removal is not approval to delete them.
Capture and retain each completed phase Pod's readback before the next upgrade:
transitioning phases removes the preceding Pod and its termination message.
Rollback can replay a stored INITIALIZE or ACTIVATE manifest without rerunning
template guards. Retained `ADMIN_PACKET` grants require separate lifecycle review.
Removal also does not prove that host bpffs state has been cleaned up; the
sensor's actual pinning and cleanup behavior is not qualified here.

## Offline technical review

The chart declares Kubernetes compatibility `>=1.31.0-0 <1.35.0-0`.
That metadata is not a tested platform matrix. For an offline defaults check:

```sh
helm lint ./lorasis-sense --strict --kube-version 1.34.0
helm template technical-review ./lorasis-sense --namespace review-only --kube-version 1.34.0
```

Default rendering should produce no Kubernetes resources. Template-only
refusals must also be checked with `helm template`: Helm lint can log a template
`fail` guard without treating it as a failed lint. Synthetic phase references
can demonstrate rendering shape only, never qualified installation or authority.
Do not use an install command as a validation step.
