# Explicit observer phases — source successor, not deployment authority

**BETA**

**FOR TECHNICAL REVIEW. NOT YET QUALIFIED FOR DEPLOYMENT.**

## Boundary and independent inputs

There is **one collection per runtime**, not all-resource namespace attestation.
The chart has no lookup, issuer, new initializer or automatic authority verifier.
`phase`, `EXISTING_PRIVATE_SUBPATH`, `EXPLICIT_PHASE` and receipt SHA256 values are
intent and references, **not approval flags**. A syntactically valid synthetic
reference can render; it must never be applied as customer configuration. The
retained administrator packet starts no workloads, but grants cluster-scoped
namespace/discovery reads and is retained after uninstall. See `README.md` for
the `ADMIN_PACKET` restriction: render for separate administrator review, never
apply it through an application install.
No mounted test is a prerequisite to authoring this source; mounted custody,
image inclusion/security and action approval remain prerequisites to using it.

Use the existing public configuration assembler against **full merged JSON values**:

```
python -I -B -m maintenance_mvp_delivery.resource_observer_config_package   --configuration /absolute/public/configuration.json   --values-file /absolute/public/values.json   --release-name <same-release> --namespace <exact-namespace>   --output-file /absolute/public/new-configmap.json
```

This command is a reference, not executed here. It validates canonical runtime-v3,
complete installation/target and public profile pins, exact collection and protected
Secret name/key consistency before producing an immutable ConfigMap. The API port,
installer target and activation source repairs are reused, not reimplemented.
Do not add fields inside the assembler's closed `machineInstaller` object. Its
existing envelope/target **names and keys** remain in full public values for
preflight even in collection; their credential volumes and RBAC appear only in
ACTIVATE. Actual Secret contents never enter Helm release state.

Before INITIALIZE, the independent custody owner must:

- Verify the exact cluster/namespace and dedicated existing claim name/UID, approved
  consumer image and module inclusion, UID/GID, prepared subtree and exclusive owner.
  A registered Pending WaitForFirstConsumer claim is not a mounted filesystem.
- Confirm the full independently enrolled stream has **never signed**, including
  scope, enrollment hash, database, custodian, registration, key epoch and stream ID.
  Neither an empty/missing filesystem nor renewed machine credentials proves this.
- Derive `signingCheckpoint.bindingSha256` with the existing
  `signing_binding(existing_checked_signer)`, under current independent authority.
  It is **not** `installationBinding.sha256`; do not hash the installation file and
  use that as a signing binding. This chart/initializer never reads a key to guess it.
- Retain that exact decision/identity/target binding externally and set its public
  SHA256 as `freshStreamAuthorizationSha256`. Verify the referenced bytes and their
  authorized origin, not merely the string length. No trust is manufactured here.

The fixed mount is `/var/lib/observer-signing`, selecting the preexisting private
subtree `checkpoint-<full signing binding SHA256>` on the dedicated claim. This is
not a new claim or payload store. Independent platform preparation must make this
leaf effective UID:effective GID **0700**, with trusted nonwritable ancestry as seen
inside the container; it must be empty only for independently proven first use.
Use explicit `namespace.runAsUser`, `runAsGroup` and matching `fsGroup` (nonzero).
The externally prepared volume root is root:G 2770, outside the mounted private
subtree. The retained OnRootMismatch design requests preservation of the private
leaf; actual CSI/fsGroup/SELinux/remount behavior must be verified. Do not change
permissions in the initializer or add a root repair container to force a pass.
A missing subPath may be created by Kubernetes with unsuitable ownership; this is
not trusted preparation and the existing initializer must refuse it.

## Separate effects and completion boundaries

All active phases set `namespace.enabled: true`. Disabled defaults use `INERT`.
Never combine phases in one Helm invocation. No Helm hook, initContainer, Job
controller, or automatic wait-and-advance script performs these steps.

| phase | observer effect | independently verified exit before proceeding |
|---|---|---|
| INITIALIZE | One bounded Never Pod calls `python -I -B -m maintenance_mvp_delivery.checkpoint_initialize --binding-sha256 <checked-digest>`. Only private checkpoint mount; no source key, credential, API token or collector. Deny-all egress is requested, not proven effective at Pod start. | Exact Pod terminated successfully with `SIGNING_INITIALIZED_READBACK`; custody owner verifies exact binding/claim/subtree and closed owner. Save the result's SHA256 as `initializationReadbackSha256`. |
| ACTIVATE | One bounded Never Pod invokes the existing `resource_observer_machine_activation` with the retained protected file flags. It mounts the observer source key, installation binding, machine CA, enrollment credential, protected target and installer API token together. Distinct preexisting installer SA GET/PATCH only the exact preexisting machine Secret. No checkpoint mount or collection Deployment. | Exact Pod and CLI success: `ACTIVATION_CONFIRMED`, COMMITTED/CONFIRMED, `collection_started:false`; verify actual target Secret CAS/readback and current registered full identity. Save result SHA256 as `activationReadbackSha256`. |
| COLLECT | One observer Deployment, replicas 1, Recreate; no initializer/activation Pod, no installer RBAC or enrollment mounts. Requires both readback references and the single separately qualified Tourniquet declaration. | Real collection, signed originals, hosted custody/ACK, visible warning/control evidence and independent verification—not just probe health. |
| PAUSED | Same observer Deployment, replicas 0; same sensor declaration. | Wait for prior observer Pod termination and bounded drain outcome, record pending/lost evidence and coverage gap; confirm exclusive owner released before next stream. |

Save each completed phase Pod's readback before advancing: the next Helm upgrade
removes that Pod and its termination message. Rollback can replay stored
INITIALIZE/ACTIVATE manifests without rerunning template guards. `PAUSED` leaves
the sensor running; its `OnDelete` strategy does not replace existing sensor Pods
on upgrade or rollback. NetworkPolicy is created alongside the initializer;
CNI enforcement is not guaranteed to precede Pod execution.

The reference guards reject missing readbacks, implicit activation, attempted
reinitialization/reactivation with existing completion references, mistaken binding,
missing/shared claims, mismatched effective group, expanded collection shape and
unqualified required sensor. They cannot detect a forged or stale external receipt.
The operator must pin each readback to the exact input configuration, stream, target,
image and Pod generation. A new Pod name, cleared receipt, `helm --force`, rollback,
uninstall/reinstall or repeated apply is **not permission to retry** a lost/unknown
effect. Standalone Never Pods avoid Job controller retries, not hostile/manual
reexecution. Any timeout/unknown result stops the sequence for reconciliation.
Runtime opens existing state and refuses absence/wrong binding. Never initialize
on restart, delete state to recover, or reinitialize an existing stream.

## Sequential ConfigMap then workload transition

Use the **same release name, namespace, Tourniquet values and sensor object**.
Do not install a second full chart for the second collection. The sequence is:

1. Independently enroll the exact ConfigMap selection (`configmaps`, `EXACT_NAMES`,
   one name). Use the existing assembler to produce its immutable configuration
   ConfigMap and separately provision/read back the protected references. Initialize
   its new stream/subtree, activate, then collect. Keep originals and coverage times.
2. Enter PAUSED with the **same old ConfigMap values** and unchanged sensor settings.
   Wait for actual old Pod termination; verify drain status and no remaining owner.
   Recreate and RWO alone do not fence a still-running or unreachable node.
3. Independently authorize/enroll the next stream for `pods`, `ALL_IN_NAMESPACE`,
   empty `exactNames`. The real runtime requires the independently pinned workload
   policy for this selection. Assemble a **new immutable configuration ConfigMap**,
   new installation/source bindings and their protected target/machine references;
   do not edit the old stream's config in place. If a declared Deployment rather
   than Pod membership is the intended subject, use the already-supported exact
   `deployments` selection as a separate stream; do not claim these are equivalent.
4. After stop/ownership readback, prepare its distinct `checkpoint-<new-binding>`
   subtree on the same dedicated observer claim. Preserve the previous subtree.
   Independently confirm fresh stream binding, INITIALIZE, ACTIVATE, then COLLECT
   that workload stream. Keep Tourniquet enabled/unchanged in every transition
   revision, including initialization and activation. Never change a completed
   stream's binding to escape a missing-state failure.

ConfigMap coverage stops before workload collection starts. The ConfigMap is **not
concurrently observed** during the workload phase, and the transition has an
explicit observation gap. Pod inventory is only the selected API-visible workload
policy projection, not all-container file attestation or complete namespace coverage.
Any cross-resource comparison must show both time windows and that limitation.
The parent-owned UI must not present historical ConfigMap evidence as current.

## Current operational facts and nonclaims

No live claim identity, claim status or environment binding is supplied by this
public chart. The independent owner must select and verify the exact observer
claim and separate sensor status claim; they must never be aliased.
This source supplies no customer image digest/security approval, fresh authority,
installed module proof, filesystem durability/antirollback, live ownership fence,
TLS qualification, installation or customer acceptance. Cloud execution,
builds and installation require separate authorization.
